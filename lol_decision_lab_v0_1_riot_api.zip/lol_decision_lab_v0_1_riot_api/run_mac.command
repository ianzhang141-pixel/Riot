#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -r requirements.txt
if [ ! -f ".env" ]; then
  cp .env.example .env
fi
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
