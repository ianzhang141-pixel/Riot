# LOL PC 决策实验室 · Riot API V0.1

这是《王者荣耀决策实验室》的 LOL PC 独立版本，数据入口改成 **Riot API 优先**。

核心目标仍然只有两个：

```text
1. 哪里做错
   V(s) = P(win | 当前 State)
   → 整局胜率曲线

2. 怎么做对
   Q(s,a) = P(win | 当前 State, 之后采取 Action a)
   → 候选行为比较

Decision Regret
= max_a Q(s,a) - Q(s, actual_action)
```

## 与王者版本最大的区别

王者：

```text
录像 → CV/OCR → Game State
```

LOL PC：

```text
Riot ID
↓
Account-V1
↓
PUUID
↓
Match-V5
↓
Match + Timeline
↓
结构化 Game State
```

因此历史训练数据不需要先通过录像 OCR 恢复经济、等级、位置等大量字段。

项目还接了本机：

```text
https://127.0.0.1:2999/liveclientdata/...
```

用于读取正在运行的 LOL 对局的 Live Client Data。

## 页面

启动后：

```text
http://127.0.0.1:8000
```

顶部有：

```text
对局库
Riot API
Live Client
```

### Riot API 页面

可以：

1. 保存 Riot Development API Key；
2. 输入 `Game Name + Tag Line`；
3. 选择 Regional Route / Platform；
4. 测试 Account-V1 / Summoner-V4；
5. 保存 PUUID；
6. 一键同步最近 1–100 场；
7. 自动下载 Match-V5 Match + Timeline；
8. 查看 API 状态、延迟和 Riot Rate-Limit headers。

### Live Client 页面

当本机正在运行一场 LOL 对局时，会连接：

```text
/liveclientdata/gamestats
/liveclientdata/activeplayer
/liveclientdata/playerlist
/liveclientdata/eventdata
```

不需要 Riot Developer API Key。

可执行：

```bash
python live_collector.py --interval 1
```

每秒保存一个本机 Live Snapshot。

## Riot API Key

在 Riot Developer Portal 登录后可以取得 Development Key。

Development Key 适合本地原型，并会定期失效，因此如果突然出现：

```text
401 / 403
```

先检查 Key 是否需要重新生成。

V0.1 有两种配置方式。

### 本机网页保存

`.env` 默认：

```text
ALLOW_WEB_KEY_SAVE=1
```

然后在 `/riot-api` 页面填 `RGAPI-...`。

它保存到：

```text
data/riot_secret.json
```

并尝试设置为仅当前用户可读。

### 服务器/线上

不要通过网页保存。

设置：

```text
ALLOW_WEB_KEY_SAVE=0
RIOT_API_KEY=RGAPI-...
```

通过云服务 Secret / Environment Variable 管理。

不要把 Key 提交到 GitHub。

## Routing

Riot Web API 有两类路由。

Regional Route：

```text
americas
asia
europe
sea
```

Platform：

```text
kr
na1
euw1
eun1
jp1
br1
la1
la2
oc1
sg2
ph2
tw2
th2
vn2
tr1
ru
...
```

例如韩服：

```text
regional_route = asia
platform = kr
```

北美：

```text
regional_route = americas
platform = na1
```

## 数据库 State

Match-V5 Timeline 每个 frame 转换为：

```text
game_time_sec

champion
team_position

total_gold
current_gold
level
xp

lane_cs
jungle_cs

x
y
map_zone

team_gold_diff

team_kills
enemy_kills

team_dragons
enemy_dragons

team_barons
enemy_barons

team_towers
enemy_towers
```

## Action 对齐

这一点非常重要。

不能这样训练：

```text
已经发生击杀后的 State
→ FIGHT
```

因为结果已经泄漏进输入。

本项目使用：

```text
State(t)
↓
观察 t → t+1 区间实际发生什么
↓
Action(t)
↓
最终 Win/Loss
```

也就是：

```text
State(t) → Next Action → Outcome
```

当前 Action taxonomy：

```text
FARM_JUNGLE
FARM_LANE
RECALL_SHOP
WARD

ROTATE_TOP
ROTATE_MID
ROTATE_BOT

FIGHT
DRAGON
HERALD_BARON
PUSH_TOWER
DEFEND
UNKNOWN
```

其中一部分 Action 可以直接由 Timeline Events 标注：

```text
CHAMPION_KILL
ELITE_MONSTER_KILL
BUILDING_KILL
WARD_PLACED
ITEM_PURCHASED
```

其余通过下一帧：

```text
CS变化
位置变化
Map Zone变化
```

推断。

V0.1 的 Action inference 仍然只是基线，需要后续继续提高。

## 本地运行

在 Mac：

```bash
cd lol_decision_lab_v0_1_riot_api

python3 -m venv .venv
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env

uvicorn app.main:app --reload --port 8000
```

或者给执行权限后双击：

```bash
chmod +x run_mac.command
./run_mac.command
```

然后浏览器：

```text
http://127.0.0.1:8000
```

## 第一批数据怎么拿

LOL 版不需要先准备录像。

例如你连接一个 Riot ID，然后同步 50 场：

```text
Riot ID
↓
Match ID × 50
↓
Match JSON × 50
↓
Timeline JSON × 50
↓
约几十个 State / Match
```

你可以连续连接不同高分段账号来扩充数据库。

但必须遵守 Riot 的 API / Player Data / Product policy，尤其公开产品、玩家数据授权和 API Key 类型。

## 训练

首页：

```text
训练 / 更新 V 与 Q
```

或：

```bash
python -m app.train
```

最低只为了验证代码管线：

```text
20 场
500 个 Timeline State
```

这个数量**不代表可用**。

更现实：

```text
几十场：
验证解析与模型训练

几百～几千场：
开始建立 V(s) baseline

数万场以上：
研究 Q(s,a)、分位置/英雄/版本建模

更大规模：
OPE / Offline RL / calibration
```

训练/测试按：

```text
match_id Group Split
```

避免同一场相邻 Timeline State 同时进入训练和测试造成指标虚高。

## Q(s,a) 的边界

V0.1 的 Q 模型实际上学习：

```text
P(win | state, historical action)
```

仍存在严重的 selection bias / confounding。

不能因为模型输出：

```text
DRAGON 63%
FARM 55%
```

就声称：

```text
“打龙严格导致 +8pp 胜率”
```

后续应该升级：

```text
π(a|s) propensity model
↓
Off-policy Evaluation
↓
Doubly Robust
↓
Fitted Q Evaluation
↓
Offline RL
```

并做 calibration 与 Action 局部支持度。

## Live Client 与产品合规

本项目把 Live Client Data 做成：

```text
数据采集
诊断
赛后建模
```

而不是实时告诉玩家：

```text
“现在去上路”
“现在开龙”
```

原因不是技术做不到，而是 Riot 的 League of Legends Game Integrity policy 对实时、会直接改变玩家决策的产品有明确限制；公开产品必须以 Riot 当前政策和审核结果为准。

## 线上部署

项目自带 Dockerfile。

在线 Web API 可以部署到：

```text
Render / Railway / Fly.io / VPS
```

但有两个区别：

### Riot Web API

服务器可以正常使用：

```text
Account-V1
Summoner-V4
Match-V5
...
```

用服务器的 `RIOT_API_KEY` Secret。

### Live Client Data API

`127.0.0.1:2999` 指的是**玩家自己的电脑**。

所以在线服务器不能直接访问玩家 PC 的本地 LOL Client。

商业版结构应该是：

```text
玩家 Desktop Companion
↓
Live Client Data API
↓
你的服务器
```

而不是：

```text
云服务器 → 访问玩家 127.0.0.1
```

## API 成本

Riot API 不是按 OpenAI token 计费。

项目的 Riot API 页面记录：

```text
endpoint
HTTP status
latency
X-App-Rate-Limit-Count
X-Method-Rate-Limit-Count
```

主要限制是 Riot 的 Key 类型与 Rate Limit，而不是每次请求的美元 token 成本。

此外：

```text
V(s) / Q(s,a)
```

当前使用本地 sklearn 模型，所以训练/推理没有 OpenAI API token 成本。

## 下一步升级建议

优先级：

```text
P0 验证不同服务器 Routing
P1 批量同步高分段账号
P2 Timeline Action inference 提纯
P3 按版本 / 位置 / 英雄做分层模型
P4 V(s) calibration
P5 propensity / OPE
P6 Q(s,a) counterfactual
P7 Riot RSO + Production Key
P8 Desktop Companion + 合规 Live data collection
```
