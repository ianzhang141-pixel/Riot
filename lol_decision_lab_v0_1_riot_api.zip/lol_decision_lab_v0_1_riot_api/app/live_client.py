from __future__ import annotations
import json,time
from datetime import datetime,timezone
import httpx
from .db import connect

BASE="https://127.0.0.1:2999"

def utc(): return datetime.now(timezone.utc).isoformat()

def get(path,timeout=2.5):
    with httpx.Client(verify=False,timeout=timeout) as c:
        r=c.get(BASE+path)
        r.raise_for_status()
        return r.json()

def snapshot(save=True):
    game=get("/liveclientdata/gamestats")
    active=get("/liveclientdata/activeplayer")
    players=get("/liveclientdata/playerlist")
    events=get("/liveclientdata/eventdata")
    obj={"gameStats":game,"activePlayer":active,"playerList":players,"events":events}
    if save:
        with connect() as c:
            c.execute("""INSERT INTO live_snapshots
            (captured_at,game_time,active_player_json,game_stats_json,player_list_json,events_json)
            VALUES(?,?,?,?,?,?)""",(utc(),game.get("gameTime"),
                json.dumps(active,ensure_ascii=False),json.dumps(game,ensure_ascii=False),
                json.dumps(players,ensure_ascii=False),json.dumps(events,ensure_ascii=False)))
    return obj

def collect(seconds=60,interval=1.0):
    end=time.time()+seconds; n=0
    while time.time()<end:
        snapshot(save=True); n+=1
        time.sleep(max(.1,interval))
    return n
