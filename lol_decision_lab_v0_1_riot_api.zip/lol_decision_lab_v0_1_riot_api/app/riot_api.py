from __future__ import annotations
import json, os, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
import httpx
from dotenv import load_dotenv
from .db import connect, SECRET_PATH

load_dotenv()

def utc():
    return datetime.now(timezone.utc).isoformat()

def get_api_key():
    env = os.getenv("RIOT_API_KEY","").strip()
    if env:
        return env
    if SECRET_PATH.exists():
        try:
            return json.loads(SECRET_PATH.read_text(encoding="utf-8")).get("riot_api_key","").strip()
        except Exception:
            return ""
    return ""

def save_api_key(key:str):
    if os.getenv("ALLOW_WEB_KEY_SAVE","1") != "1":
        raise RuntimeError("线上环境已禁止通过网页保存 API Key，请改用 RIOT_API_KEY 环境变量。")
    key = key.strip()
    if not key:
        raise RuntimeError("API Key 不能为空。")
    SECRET_PATH.write_text(json.dumps({"riot_api_key": key}), encoding="utf-8")
    try:
        os.chmod(SECRET_PATH, 0o600)
    except Exception:
        pass

def masked_key():
    key = get_api_key()
    if not key:
        return ""
    if len(key) < 12:
        return "••••••"
    return key[:5] + "…" + key[-4:]

class RiotAPIError(RuntimeError):
    pass

class RiotClient:
    def __init__(self, api_key=None, timeout=15.0):
        self.api_key = api_key or get_api_key()
        if not self.api_key:
            raise RiotAPIError("尚未配置 Riot API Key。")
        self.client = httpx.Client(timeout=timeout, headers={"X-Riot-Token": self.api_key})

    def close(self):
        self.client.close()

    def _get(self, host, path, params=None, regional_route=None, platform=None):
        url = f"https://{host}{path}"
        t0 = time.perf_counter()
        status = None
        error = None
        headers = {}
        try:
            r = self.client.get(url, params=params)
            status = r.status_code
            headers = r.headers
            if r.status_code == 429:
                retry = r.headers.get("Retry-After","?")
                raise RiotAPIError(f"Riot API 限流 429；Retry-After={retry}s。")
            if r.status_code == 401:
                raise RiotAPIError("401：API Key 无效或已过期。开发 Key 通常需要重新生成。")
            if r.status_code == 403:
                raise RiotAPIError("403：API Key 没有权限访问该接口，或 Key 已失效。")
            if r.status_code == 404:
                raise RiotAPIError("404：没有找到对应玩家/比赛/资源，请检查 Riot ID、Tag 和路由。")
            r.raise_for_status()
            return r.json()
        except Exception as e:
            error = f"{type(e).__name__}: {e}"
            raise
        finally:
            latency = (time.perf_counter()-t0)*1000
            with connect() as c:
                c.execute("""INSERT INTO riot_api_calls
                (endpoint,status_code,latency_ms,regional_route,platform,rate_app_count,rate_method_count,error_text,created_at)
                VALUES(?,?,?,?,?,?,?,?,?)""",(
                    path,status,latency,regional_route,platform,
                    headers.get("X-App-Rate-Limit-Count"),
                    headers.get("X-Method-Rate-Limit-Count"),
                    error,utc()
                ))

    def account_by_riot_id(self, game_name, tag_line, regional_route):
        path = f"/riot/account/v1/accounts/by-riot-id/{quote(game_name,safe='')}/{quote(tag_line,safe='')}"
        return self._get(f"{regional_route}.api.riotgames.com", path, regional_route=regional_route)

    def summoner_by_puuid(self, puuid, platform):
        path = f"/lol/summoner/v4/summoners/by-puuid/{quote(puuid,safe='')}"
        return self._get(f"{platform}.api.riotgames.com", path, platform=platform)

    def match_ids(self, puuid, regional_route, start=0, count=20, queue=None):
        path = f"/lol/match/v5/matches/by-puuid/{quote(puuid,safe='')}/ids"
        params = {"start": int(start), "count": min(int(count), 100)}
        if queue:
            params["queue"] = int(queue)
        return self._get(f"{regional_route}.api.riotgames.com", path, params=params, regional_route=regional_route)

    def match(self, match_id, regional_route):
        path = f"/lol/match/v5/matches/{quote(match_id,safe='')}"
        return self._get(f"{regional_route}.api.riotgames.com", path, regional_route=regional_route)

    def timeline(self, match_id, regional_route):
        path = f"/lol/match/v5/matches/{quote(match_id,safe='')}/timeline"
        return self._get(f"{regional_route}.api.riotgames.com", path, regional_route=regional_route)
