ACTIONS = [
    "FARM_JUNGLE","FARM_LANE","RECALL_SHOP","WARD",
    "ROTATE_TOP","ROTATE_MID","ROTATE_BOT",
    "FIGHT","DRAGON","HERALD_BARON","PUSH_TOWER",
    "DEFEND","UNKNOWN"
]

NUMERIC_FEATURES = [
    "game_time_sec","total_gold","current_gold","level","xp",
    "lane_cs","jungle_cs","x","y",
    "team_gold_diff","team_kills","enemy_kills",
    "team_dragons","enemy_dragons","team_barons","enemy_barons",
    "team_towers","enemy_towers"
]

CATEGORICAL_FEATURES = [
    "platform","regional_route","champion","team_position","map_zone"
]

MODEL_FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES

REGION_PRESETS = {
    "KR": ("asia","kr"),
    "JP": ("asia","jp1"),
    "NA": ("americas","na1"),
    "BR": ("americas","br1"),
    "LAN": ("americas","la1"),
    "LAS": ("americas","la2"),
    "EUW": ("europe","euw1"),
    "EUNE": ("europe","eun1"),
    "TR": ("europe","tr1"),
    "RU": ("europe","ru"),
    "OCE": ("sea","oc1"),
    "SG": ("sea","sg2"),
    "PH": ("sea","ph2"),
    "TW": ("sea","tw2"),
    "TH": ("sea","th2"),
    "VN": ("sea","vn2"),
}
