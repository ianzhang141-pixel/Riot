from __future__ import annotations
import os, sqlite3
from pathlib import Path
from contextlib import contextmanager
from dotenv import load_dotenv

load_dotenv()
DATA_DIR = Path(os.getenv("DATA_DIR","./data")).resolve()
MODEL_DIR = DATA_DIR/"models"
DB_PATH = DATA_DIR/"lol.db"
SECRET_PATH = DATA_DIR/"riot_secret.json"
for p in [DATA_DIR, MODEL_DIR]:
    p.mkdir(parents=True, exist_ok=True)

SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS riot_accounts(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 game_name TEXT NOT NULL,
 tag_line TEXT NOT NULL,
 puuid TEXT NOT NULL UNIQUE,
 regional_route TEXT NOT NULL,
 platform TEXT NOT NULL,
 summoner_id TEXT,
 account_id TEXT,
 profile_icon_id INTEGER,
 summoner_level INTEGER,
 updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS matches(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 match_id TEXT NOT NULL UNIQUE,
 account_puuid TEXT NOT NULL,
 platform TEXT,
 regional_route TEXT,
 game_version TEXT,
 queue_id INTEGER,
 game_mode TEXT,
 game_type TEXT,
 game_creation INTEGER,
 game_duration INTEGER,
 champion TEXT,
 team_position TEXT,
 participant_id INTEGER,
 team_id INTEGER,
 win INTEGER,
 kills INTEGER,
 deaths INTEGER,
 assists INTEGER,
 gold_earned INTEGER,
 total_minions INTEGER,
 neutral_minions INTEGER,
 status TEXT NOT NULL DEFAULT 'synced',
 synced_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS timeline_states(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 match_id TEXT NOT NULL,
 account_puuid TEXT NOT NULL,
 frame_index INTEGER NOT NULL,
 timestamp_ms INTEGER NOT NULL,
 state_json TEXT NOT NULL,
 observed_action TEXT,
 created_at TEXT NOT NULL,
 UNIQUE(match_id,account_puuid,frame_index)
);

CREATE TABLE IF NOT EXISTS analyses(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 state_id INTEGER NOT NULL,
 model_version TEXT NOT NULL,
 v_win REAL,
 actual_q REAL,
 best_q REAL,
 best_action TEXT,
 regret REAL,
 q_json TEXT,
 created_at TEXT NOT NULL,
 UNIQUE(state_id,model_version)
);

CREATE TABLE IF NOT EXISTS riot_api_calls(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 endpoint TEXT,
 status_code INTEGER,
 latency_ms REAL,
 regional_route TEXT,
 platform TEXT,
 rate_app_count TEXT,
 rate_method_count TEXT,
 error_text TEXT,
 created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS live_snapshots(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 captured_at TEXT NOT NULL,
 game_time REAL,
 active_player_json TEXT,
 game_stats_json TEXT,
 player_list_json TEXT,
 events_json TEXT
);
"""

@contextmanager
def connect():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with connect() as c:
        c.executescript(SCHEMA)
