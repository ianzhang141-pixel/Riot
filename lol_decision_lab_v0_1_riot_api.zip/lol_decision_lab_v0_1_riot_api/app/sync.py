from __future__ import annotations
from datetime import datetime, timezone
from .db import connect
from .riot_api import RiotClient
from .timeline import parse_and_store

def utc():
    return datetime.now(timezone.utc).isoformat()

def save_account(game_name,tag_line,regional_route,platform):
    client=RiotClient()
    try:
        account=client.account_by_riot_id(game_name,tag_line,regional_route)
        summoner=client.summoner_by_puuid(account["puuid"],platform)
    finally:
        client.close()
    with connect() as c:
        c.execute("""INSERT INTO riot_accounts
        (game_name,tag_line,puuid,regional_route,platform,summoner_id,account_id,profile_icon_id,summoner_level,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(puuid) DO UPDATE SET
        game_name=excluded.game_name,tag_line=excluded.tag_line,regional_route=excluded.regional_route,
        platform=excluded.platform,summoner_id=excluded.summoner_id,account_id=excluded.account_id,
        profile_icon_id=excluded.profile_icon_id,summoner_level=excluded.summoner_level,updated_at=excluded.updated_at
        """,(game_name,tag_line,account["puuid"],regional_route,platform,
             summoner.get("id"),summoner.get("accountId"),summoner.get("profileIconId"),
             summoner.get("summonerLevel"),utc()))
    return account,summoner

def sync_recent_matches(puuid,regional_route,platform,count=20,queue=None):
    client=RiotClient()
    try:
        ids=client.match_ids(puuid,regional_route,count=count,queue=queue)
        synced=0
        for mid in ids:
            match=client.match(mid,regional_route)
            timeline=client.timeline(mid,regional_route)
            info=match.get("info",{})
            me=next((p for p in info.get("participants",[]) if p.get("puuid")==puuid),None)
            if not me:
                continue
            with connect() as c:
                c.execute("""INSERT INTO matches
                (match_id,account_puuid,platform,regional_route,game_version,queue_id,game_mode,game_type,
                 game_creation,game_duration,champion,team_position,participant_id,team_id,win,kills,deaths,assists,
                 gold_earned,total_minions,neutral_minions,status,synced_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'synced',?)
                ON CONFLICT(match_id) DO UPDATE SET
                account_puuid=excluded.account_puuid,champion=excluded.champion,team_position=excluded.team_position,
                win=excluded.win,kills=excluded.kills,deaths=excluded.deaths,assists=excluded.assists,
                gold_earned=excluded.gold_earned,total_minions=excluded.total_minions,
                neutral_minions=excluded.neutral_minions,status='synced',synced_at=excluded.synced_at
                """,(mid,puuid,platform,regional_route,info.get("gameVersion"),info.get("queueId"),
                     info.get("gameMode"),info.get("gameType"),info.get("gameCreation"),info.get("gameDuration"),
                     me.get("championName"),me.get("teamPosition") or me.get("individualPosition"),
                     me.get("participantId"),me.get("teamId"),1 if me.get("win") else 0,
                     me.get("kills"),me.get("deaths"),me.get("assists"),me.get("goldEarned"),
                     me.get("totalMinionsKilled"),me.get("neutralMinionsKilled"),utc()))
            parse_and_store(match,timeline,puuid,platform,regional_route)
            synced+=1
        return synced,ids
    finally:
        client.close()
