from __future__ import annotations
import json, math
from datetime import datetime, timezone
from .db import connect

def utc():
    return datetime.now(timezone.utc).isoformat()

def map_zone(x,y):
    if x is None or y is None:
        return "UNKNOWN"
    x=float(x); y=float(y)
    if x < 2400 and y < 2400: return "BLUE_BASE"
    if x > 12600 and y > 12600: return "RED_BASE"
    if y > 10300 and x < 7000: return "TOP_LANE"
    if x > 10300 and y < 7000: return "BOT_LANE"
    if abs(x-y) < 1700 and 3000 < x < 12000: return "MID_LANE"
    if abs((x+y)-15000) < 1300 and 2500 < x < 12500: return "RIVER"
    if x < 7500 and y < 7500: return "BLUE_BOTTOM_JUNGLE"
    if x < 7500 and y >= 7500: return "BLUE_TOP_JUNGLE"
    if x >= 7500 and y < 7500: return "RED_BOTTOM_JUNGLE"
    return "RED_TOP_JUNGLE"

def classify_next_action(cur, nxt, next_frame_events, participant_id):
    """Label action taken AFTER cur state, during cur -> nxt interval."""
    p=participant_id
    for e in next_frame_events:
        t=e.get("type")
        if t in {"ITEM_PURCHASED","ITEM_SOLD"} and e.get("participantId")==p:
            return "RECALL_SHOP"
    for e in next_frame_events:
        if e.get("type")=="WARD_PLACED" and e.get("creatorId")==p:
            return "WARD"
    for e in next_frame_events:
        t=e.get("type")
        if t=="CHAMPION_KILL" and (e.get("killerId")==p or e.get("victimId")==p or p in (e.get("assistingParticipantIds") or [])):
            return "FIGHT"
        if t=="ELITE_MONSTER_KILL" and e.get("killerId")==p:
            return "DRAGON" if e.get("monsterType")=="DRAGON" else "HERALD_BARON"
        if t=="BUILDING_KILL" and e.get("killerId")==p:
            return "PUSH_TOWER"

    dj=(nxt.get("jungle_cs") or 0)-(cur.get("jungle_cs") or 0)
    dl=(nxt.get("lane_cs") or 0)-(cur.get("lane_cs") or 0)
    if dj >= 2 and dj > dl: return "FARM_JUNGLE"
    if dl >= 2: return "FARM_LANE"

    x1,y1=cur.get("x"),cur.get("y")
    x2,y2=nxt.get("x"),nxt.get("y")
    if None not in (x1,y1,x2,y2):
        dist=math.hypot(x2-x1,y2-y1)
        if dist > 1800 and nxt.get("map_zone") != cur.get("map_zone"):
            z=nxt.get("map_zone","")
            if z=="TOP_LANE": return "ROTATE_TOP"
            if z=="MID_LANE": return "ROTATE_MID"
            if z=="BOT_LANE": return "ROTATE_BOT"
    return "UNKNOWN"

def parse_and_store(match_obj,timeline_obj,puuid,platform,regional_route):
    info=match_obj.get("info",{})
    participants=info.get("participants",[])
    me=next((p for p in participants if p.get("puuid")==puuid),None)
    if not me:
        raise RuntimeError("该 PUUID 不在这场比赛参与者列表中。")
    pid=int(me["participantId"]); team_id=int(me["teamId"])
    enemy_team=200 if team_id==100 else 100
    participant_team={int(p["participantId"]):int(p["teamId"]) for p in participants}
    frames=timeline_obj.get("info",{}).get("frames",[])

    cumulative={
        100:{"kills":0,"dragons":0,"barons":0,"towers":0},
        200:{"kills":0,"dragons":0,"barons":0,"towers":0},
    }
    parsed=[]
    for i,frame in enumerate(frames):
        # Events in this frame have happened by the time this state is recorded.
        for e in frame.get("events",[]):
            et=e.get("type")
            if et=="CHAMPION_KILL":
                killer=int(e.get("killerId") or 0)
                kt=participant_team.get(killer)
                if kt in cumulative: cumulative[kt]["kills"]+=1
            elif et=="ELITE_MONSTER_KILL":
                killer=int(e.get("killerId") or 0)
                kt=participant_team.get(killer)
                if kt in cumulative:
                    mt=e.get("monsterType","")
                    if mt=="DRAGON": cumulative[kt]["dragons"]+=1
                    elif mt in {"BARON_NASHOR","RIFTHERALD","HORDE"}: cumulative[kt]["barons"]+=1
            elif et=="BUILDING_KILL" and e.get("buildingType")=="TOWER_BUILDING":
                destroyed=e.get("teamId")
                scorer=200 if destroyed==100 else 100 if destroyed==200 else None
                if scorer in cumulative: cumulative[scorer]["towers"]+=1

        pframes=frame.get("participantFrames",{})
        pf=pframes.get(str(pid)) or pframes.get(pid)
        if not pf: continue
        pos=pf.get("position") or {}
        x,y=pos.get("x"),pos.get("y")
        team_gold=enemy_gold=0
        for k,v in pframes.items():
            try: kpid=int(k)
            except Exception: continue
            tid=participant_team.get(kpid)
            g=int(v.get("totalGold") or 0)
            if tid==team_id: team_gold+=g
            elif tid in {100,200}: enemy_gold+=g
        state={
            "game_time_sec":int(frame.get("timestamp",0))/1000.0,
            "platform":platform,"regional_route":regional_route,
            "champion":me.get("championName") or "UNKNOWN",
            "team_position":me.get("teamPosition") or me.get("individualPosition") or "UNKNOWN",
            "total_gold":pf.get("totalGold"),"current_gold":pf.get("currentGold"),
            "level":pf.get("level"),"xp":pf.get("xp"),
            "lane_cs":pf.get("minionsKilled"),"jungle_cs":pf.get("jungleMinionsKilled"),
            "x":x,"y":y,"map_zone":map_zone(x,y),
            "team_gold_diff":team_gold-enemy_gold,
            "team_kills":cumulative[team_id]["kills"],"enemy_kills":cumulative[enemy_team]["kills"],
            "team_dragons":cumulative[team_id]["dragons"],"enemy_dragons":cumulative[enemy_team]["dragons"],
            "team_barons":cumulative[team_id]["barons"],"enemy_barons":cumulative[enemy_team]["barons"],
            "team_towers":cumulative[team_id]["towers"],"enemy_towers":cumulative[enemy_team]["towers"],
        }
        parsed.append({"frame_index":i,"timestamp_ms":int(frame.get("timestamp",0)),
                       "state":state,"events":frame.get("events",[])})

    written=0
    for j,item in enumerate(parsed):
        if j+1 < len(parsed):
            action=classify_next_action(item["state"],parsed[j+1]["state"],parsed[j+1]["events"],pid)
        else:
            action="UNKNOWN"
        with connect() as c:
            c.execute("""INSERT INTO timeline_states
            (match_id,account_puuid,frame_index,timestamp_ms,state_json,observed_action,created_at)
            VALUES(?,?,?,?,?,?,?)
            ON CONFLICT(match_id,account_puuid,frame_index) DO UPDATE SET
            timestamp_ms=excluded.timestamp_ms,state_json=excluded.state_json,
            observed_action=excluded.observed_action,created_at=excluded.created_at
            """,(match_obj["metadata"]["matchId"],puuid,item["frame_index"],item["timestamp_ms"],
                 json.dumps(item["state"],ensure_ascii=False),action,utc()))
        written+=1
    return written
