from __future__ import annotations
import json,os,joblib,pandas as pd
from datetime import datetime,timezone
from .db import connect,MODEL_DIR
from .schema import ACTIONS,MODEL_FEATURES

def utc(): return datetime.now(timezone.utc).isoformat()

def load_models():
    vp,qp,mp=MODEL_DIR/"value_model.joblib",MODEL_DIR/"q_model.joblib",MODEL_DIR/"model_meta.json"
    if not(vp.exists() and qp.exists() and mp.exists()):
        return None,None,None
    return joblib.load(vp),joblib.load(qp),json.loads(mp.read_text(encoding="utf-8"))

def analyze_match(match_id):
    vm,qm,meta=load_models()
    if meta is None: return 0
    support=meta.get("action_support",{})
    min_support=int(os.getenv("MIN_ACTION_SUPPORT","100"))
    version=meta["version"]
    with connect() as c:
        rows=c.execute("SELECT * FROM timeline_states WHERE match_id=? ORDER BY timestamp_ms",(match_id,)).fetchall()
    n=0
    for r in rows:
        st=json.loads(r["state_json"])
        base={f:st.get(f) for f in MODEL_FEATURES}
        sdf=pd.DataFrame([base])
        v=float(vm.predict_proba(sdf[MODEL_FEATURES])[:,1][0])
        candidates=[]; names=[]
        for a in ACTIONS:
            if a=="UNKNOWN": continue
            sup=int(support.get(a,0))
            if sup<min_support: continue
            row=dict(base); row["action"]=a
            candidates.append(row); names.append((a,sup))
        qmap={}; best_action=None; best_q=None
        if candidates:
            qdf=pd.DataFrame(candidates)
            probs=qm.predict_proba(qdf[MODEL_FEATURES+["action"]])[:,1]
            for (a,sup),p in zip(names,probs):
                qmap[a]={"q":float(p),"support":sup}
            best_action,best=max(qmap.items(),key=lambda kv:kv[1]["q"])
            best_q=float(best["q"])
        actual=(r["observed_action"] or "UNKNOWN").upper()
        actual_q=float(qmap[actual]["q"]) if actual in qmap else None
        regret=max(0.0,best_q-actual_q) if best_q is not None and actual_q is not None else None
        with connect() as c:
            c.execute("""INSERT INTO analyses
            (state_id,model_version,v_win,actual_q,best_q,best_action,regret,q_json,created_at)
            VALUES(?,?,?,?,?,?,?,?,?)
            ON CONFLICT(state_id,model_version) DO UPDATE SET
            v_win=excluded.v_win,actual_q=excluded.actual_q,best_q=excluded.best_q,
            best_action=excluded.best_action,regret=excluded.regret,q_json=excluded.q_json,
            created_at=excluded.created_at
            """,(r["id"],version,v,actual_q,best_q,best_action,regret,json.dumps(qmap,ensure_ascii=False),utc()))
        n+=1
    return n

def analyze_all():
    with connect() as c:
        ids=[r["match_id"] for r in c.execute("SELECT match_id FROM matches WHERE status='synced'").fetchall()]
    for mid in ids:
        analyze_match(mid)
