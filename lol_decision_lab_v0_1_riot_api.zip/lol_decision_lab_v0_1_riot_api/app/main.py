from __future__ import annotations
import base64,json,os,secrets
from urllib.parse import quote
from pathlib import Path
from fastapi import FastAPI,Request,Form,BackgroundTasks
from fastapi.responses import HTMLResponse,RedirectResponse,Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv

from .db import init_db,connect,MODEL_DIR
from .riot_api import save_api_key,masked_key,get_api_key
from .sync import save_account,sync_recent_matches
from .live_client import snapshot as live_snapshot

load_dotenv(); init_db()
app=FastAPI(title="LOL PC 决策实验室 · Riot API")
BASE=Path(__file__).resolve().parent
templates=Jinja2Templates(directory=str(BASE/"templates"))
app.mount("/static",StaticFiles(directory=str(BASE/"static")),name="static")

def model_meta():
    p=MODEL_DIR/"model_meta.json"
    try: return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
    except Exception: return None

@app.middleware("http")
async def auth(request:Request,call_next):
    user=os.getenv("APP_USERNAME","").strip()
    password=os.getenv("APP_PASSWORD","").strip()
    if not password:
        return await call_next(request)
    hdr=request.headers.get("Authorization",""); ok=False
    if hdr.startswith("Basic "):
        try:
            u,p=base64.b64decode(hdr[6:]).decode().split(":",1)
            ok=secrets.compare_digest(u,user) and secrets.compare_digest(p,password)
        except Exception:
            pass
    if not ok:
        return Response("Authentication required",401,headers={"WWW-Authenticate":'Basic realm="LOL Decision Lab"'})
    return await call_next(request)

@app.get("/",response_class=HTMLResponse)
def home(request:Request):
    with connect() as c:
        stats=c.execute("""SELECT
          (SELECT COUNT(*) FROM riot_accounts) accounts,
          (SELECT COUNT(*) FROM matches) matches,
          (SELECT COUNT(*) FROM timeline_states) states,
          (SELECT COUNT(*) FROM live_snapshots) live_snapshots,
          (SELECT COUNT(*) FROM riot_api_calls) api_calls
        """).fetchone()
        matches=c.execute("SELECT * FROM matches ORDER BY game_creation DESC LIMIT 50").fetchall()
        accounts=c.execute("SELECT * FROM riot_accounts ORDER BY updated_at DESC").fetchall()
    return templates.TemplateResponse(request=request,name="home.html",context={
        "stats":stats,"matches":matches,"accounts":accounts,"meta":model_meta()
    })

@app.get("/riot-api",response_class=HTMLResponse)
def riot_page(request:Request):
    with connect() as c:
        accounts=c.execute("SELECT * FROM riot_accounts ORDER BY updated_at DESC").fetchall()
        calls=c.execute("SELECT * FROM riot_api_calls ORDER BY id DESC LIMIT 30").fetchall()
    return templates.TemplateResponse(request=request,name="riot.html",context={
        "accounts":accounts,"calls":calls,"masked_key":masked_key(),
        "allow_save":os.getenv("ALLOW_WEB_KEY_SAVE","1")=="1",
        "has_key":bool(get_api_key()),
    })

@app.post("/riot-api/save-key")
def riot_save_key(api_key:str=Form(...)):
    try:
        save_api_key(api_key)
        return RedirectResponse("/riot-api?ok=key",303)
    except Exception as e:
        return RedirectResponse("/riot-api?error="+quote(str(e)),303)

@app.post("/riot-api/connect")
def riot_connect(game_name:str=Form(...),tag_line:str=Form(...),
                 regional_route:str=Form(...),platform:str=Form(...)):
    try:
        save_account(game_name.strip(),tag_line.strip(),regional_route.strip(),platform.strip())
        return RedirectResponse("/riot-api?ok=connected",303)
    except Exception as e:
        return RedirectResponse("/riot-api?error="+quote(str(e)),303)

@app.post("/riot-api/sync/{account_id}")
def riot_sync(account_id:int,background_tasks:BackgroundTasks,
              count:int=Form(20),queue:str=Form("")):
    with connect() as c:
        a=c.execute("SELECT * FROM riot_accounts WHERE id=?",(account_id,)).fetchone()
    if not a:
        return RedirectResponse("/riot-api?error=account%20not%20found",303)
    q=int(queue) if queue.strip().isdigit() else None
    background_tasks.add_task(sync_recent_matches,a["puuid"],a["regional_route"],a["platform"],min(max(count,1),100),q)
    return RedirectResponse(f"/account/{account_id}",303)

@app.get("/account/{account_id}",response_class=HTMLResponse)
def account_page(request:Request,account_id:int):
    with connect() as c:
        a=c.execute("SELECT * FROM riot_accounts WHERE id=?",(account_id,)).fetchone()
        if not a: return HTMLResponse("Account not found",404)
        matches=c.execute("SELECT * FROM matches WHERE account_puuid=? ORDER BY game_creation DESC",(a["puuid"],)).fetchall()
    return templates.TemplateResponse(request=request,name="account.html",context={"account":a,"matches":matches})

@app.get("/match/{match_id}",response_class=HTMLResponse)
def match_page(request:Request,match_id:str):
    meta=model_meta()
    with connect() as c:
        m=c.execute("SELECT * FROM matches WHERE match_id=?",(match_id,)).fetchone()
        if not m: return HTMLResponse("Match not found",404)
        if meta:
            rows=c.execute("""SELECT s.*,a.v_win,a.actual_q,a.best_q,a.best_action,a.regret,a.q_json
            FROM timeline_states s LEFT JOIN analyses a
            ON a.state_id=s.id AND a.model_version=?
            WHERE s.match_id=? ORDER BY s.timestamp_ms""",(meta["version"],match_id)).fetchall()
        else:
            rows=c.execute("""SELECT s.*,NULL v_win,NULL actual_q,NULL best_q,NULL best_action,NULL regret,NULL q_json
            FROM timeline_states s WHERE s.match_id=? ORDER BY s.timestamp_ms""",(match_id,)).fetchall()
    curve=[]; errors=[]
    for r in rows:
        st=json.loads(r["state_json"])
        q=json.loads(r["q_json"]) if r["q_json"] else {}
        item={
            "t":r["timestamp_ms"]/1000.0,
            "v":None if r["v_win"] is None else float(r["v_win"]),
            "action":r["observed_action"],"zone":st.get("map_zone"),
            "gold_diff":st.get("team_gold_diff"),
            "best_action":r["best_action"],
            "actual_q":None if r["actual_q"] is None else float(r["actual_q"]),
            "best_q":None if r["best_q"] is None else float(r["best_q"]),
            "regret":None if r["regret"] is None else float(r["regret"]),
            "q_list":sorted([{"action":a,"q":v["q"],"support":v["support"]} for a,v in q.items()],
                            key=lambda x:x["q"],reverse=True)
        }
        curve.append(item)
        if item["regret"] is not None and item["regret"]>=.05:
            errors.append(item)
    errors.sort(key=lambda x:x["regret"],reverse=True)
    return templates.TemplateResponse(request=request,name="match.html",context={
        "match":m,"curve_json":json.dumps(curve,ensure_ascii=False),
        "errors":errors[:30],"meta":meta
    })

@app.get("/live",response_class=HTMLResponse)
def live_page(request:Request):
    data=None; error=None
    try:
        data=live_snapshot(save=False)
    except Exception as e:
        error=f"{type(e).__name__}: {e}"
    with connect() as c:
        count=c.execute("SELECT COUNT(*) n FROM live_snapshots").fetchone()["n"]
    return templates.TemplateResponse(request=request,name="live.html",context={
        "data":data,"error":error,"snapshot_count":count
    })

@app.post("/live/save")
def live_save():
    try:
        live_snapshot(save=True)
        return RedirectResponse("/live?ok=saved",303)
    except Exception as e:
        return RedirectResponse("/live?error="+quote(str(e)),303)

@app.post("/train")
def train(background_tasks:BackgroundTasks):
    def run():
        from .train import train_models
        try:
            train_models()
            p=MODEL_DIR/"last_train_error.txt"
            if p.exists(): p.unlink()
        except Exception as e:
            (MODEL_DIR/"last_train_error.txt").write_text(f"{type(e).__name__}: {e}",encoding="utf-8")
    background_tasks.add_task(run)
    return RedirectResponse("/",303)
