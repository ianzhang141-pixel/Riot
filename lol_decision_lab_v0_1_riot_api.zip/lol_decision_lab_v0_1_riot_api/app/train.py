from __future__ import annotations
import json
from datetime import datetime, timezone
import joblib, numpy as np, pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import roc_auc_score,brier_score_loss,log_loss,accuracy_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OrdinalEncoder
from sklearn.ensemble import HistGradientBoostingClassifier
from .db import connect,MODEL_DIR,init_db
from .schema import MODEL_FEATURES,NUMERIC_FEATURES,CATEGORICAL_FEATURES,ACTIONS

def utc(): return datetime.now(timezone.utc).isoformat()

def load_df():
    rows=[]
    with connect() as c:
        data=c.execute("""SELECT s.*,m.win FROM timeline_states s
                          JOIN matches m ON m.match_id=s.match_id
                          WHERE m.status='synced'""").fetchall()
    for r in data:
        st=json.loads(r["state_json"])
        row={"state_id":r["id"],"match_id":r["match_id"],"win":int(r["win"]),
             "action":(r["observed_action"] or "UNKNOWN").upper()}
        for f in MODEL_FEATURES:
            row[f]=st.get(f)
        rows.append(row)
    return pd.DataFrame(rows)

def prep(cat_features):
    num=Pipeline([("imputer",SimpleImputer(strategy="median"))])
    cat=Pipeline([
        ("imputer",SimpleImputer(strategy="most_frequent")),
        ("ordinal",OrdinalEncoder(handle_unknown="use_encoded_value",unknown_value=-1))
    ])
    return ColumnTransformer([
        ("num",num,NUMERIC_FEATURES),
        ("cat",cat,cat_features)
    ],remainder="drop",sparse_threshold=0)

def model(cat_features,seed=42):
    return Pipeline([
        ("prep",prep(cat_features)),
        ("clf",HistGradientBoostingClassifier(
            learning_rate=.05,max_iter=300,max_leaf_nodes=31,
            min_samples_leaf=20,l2_regularization=1.0,random_state=seed
        ))
    ])

def metrics(y,p):
    pred=(p>=.5).astype(int)
    out={
        "accuracy":float(accuracy_score(y,pred)),
        "brier":float(brier_score_loss(y,p)),
        "log_loss":float(log_loss(y,np.c_[1-p,p],labels=[0,1])),
        "roc_auc":None
    }
    if len(np.unique(y))==2:
        out["roc_auc"]=float(roc_auc_score(y,p))
    return out

def train_models():
    init_db(); df=load_df()
    if len(df)<500 or df["match_id"].nunique()<20:
        raise RuntimeError("数据不足：至少先同步 20 场、500 个 Timeline State 验证训练管线；可靠模型需要更多。")
    gs=GroupShuffleSplit(n_splits=1,test_size=.2,random_state=42)
    tr_i,te_i=next(gs.split(df,groups=df["match_id"]))
    tr,te=df.iloc[tr_i],df.iloc[te_i]

    vm=model(CATEGORICAL_FEATURES,42)
    vm.fit(tr[MODEL_FEATURES],tr["win"])
    vp=vm.predict_proba(te[MODEL_FEATURES])[:,1]
    vmet=metrics(te["win"].to_numpy(),vp)

    qdf=df[df["action"].isin(ACTIONS)].copy()
    qdf=qdf[qdf["action"]!="UNKNOWN"]
    if len(qdf)<400 or qdf["match_id"].nunique()<20:
        raise RuntimeError("Q 模型 Action 数据不足。先继续同步更多比赛。")
    qfeatures=MODEL_FEATURES+["action"]
    qgs=GroupShuffleSplit(n_splits=1,test_size=.2,random_state=43)
    qtr_i,qte_i=next(qgs.split(qdf,groups=qdf["match_id"]))
    qtr,qte=qdf.iloc[qtr_i],qdf.iloc[qte_i]
    qm=model(CATEGORICAL_FEATURES+["action"],43)
    qm.fit(qtr[qfeatures],qtr["win"])
    qp=qm.predict_proba(qte[qfeatures])[:,1]
    qmet=metrics(qte["win"].to_numpy(),qp)

    version=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    joblib.dump(vm,MODEL_DIR/"value_model.joblib")
    joblib.dump(qm,MODEL_DIR/"q_model.joblib")
    support=qdf["action"].value_counts().to_dict()
    meta={
        "version":version,"trained_at":utc(),
        "observational_baseline":True,
        "state_rows":int(len(df)),"q_rows":int(len(qdf)),
        "matches":int(df["match_id"].nunique()),
        "value_metrics":vmet,"q_metrics":qmet,
        "action_support":{k:int(v) for k,v in support.items()}
    }
    (MODEL_DIR/"model_meta.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
    from .inference import analyze_all
    analyze_all()
    return meta

if __name__=="__main__":
    print(json.dumps(train_models(),ensure_ascii=False,indent=2))
