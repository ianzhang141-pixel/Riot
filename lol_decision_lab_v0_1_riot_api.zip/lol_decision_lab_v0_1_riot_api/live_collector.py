#!/usr/bin/env python3
import argparse,time
from app.live_client import snapshot
p=argparse.ArgumentParser()
p.add_argument("--interval",type=float,default=1.0)
args=p.parse_args()
print("LOL Live Client Data collector. Ctrl+C 停止。")
while True:
    try:
        s=snapshot(save=True)
        g=s["gameStats"]; a=s["activePlayer"]
        print(f'{g.get("gameTime",0):7.1f}s | {a.get("summonerName") or a.get("riotId") or "active player"} | snapshots saved')
        time.sleep(max(.1,args.interval))
    except KeyboardInterrupt:
        break
    except Exception as e:
        print("等待对局 / 连接失败:",e)
        time.sleep(2)
