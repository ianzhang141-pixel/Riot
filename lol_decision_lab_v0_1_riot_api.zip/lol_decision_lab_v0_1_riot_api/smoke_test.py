from app.db import init_db,connect,DB_PATH
from app.schema import ACTIONS,MODEL_FEATURES
init_db()
with connect() as c:
    tables=[r["name"] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()]
print("DB:",DB_PATH)
print("Tables:",tables)
print("Actions:",len(ACTIONS))
print("Features:",len(MODEL_FEATURES))
print("Smoke test OK")
